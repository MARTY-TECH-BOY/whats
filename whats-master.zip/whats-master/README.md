# whats
<br><span size="20px" color="#777"><b>WhatsApp Sploit</b></span>
<p>
  pkg update && pkg upgrade<br>
  pkg install python2<br>
  pip2 install mechanize<br>
  pkg install git<br>
  git clone https://github.com/gellmoxer/whats<br>
  cd whats<br>
  python2 whats.py<br>
  <br>
<img src="https://github.com/gellmoxer/pic/blob/master/whats.JPG" width="120px" alt="screenshot">

<br>
## Use Metasploit, SSH
